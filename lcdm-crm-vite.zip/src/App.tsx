import CRM from "./CRM";
export default function App() {
  return <CRM />;
}
