"use client";
import CRM_LCDM_Prototype from "@/components/CRM";

export default function Page() {
  return <CRM_LCDM_Prototype />;
}
