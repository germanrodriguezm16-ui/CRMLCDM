# CRM LCDM (Next.js + Tailwind)

Este proyecto es un arranque listo para desplegar tu CRM externo **sin copiar/pegar código**.

## Cómo usar sin crear carpetas
1. **Descarga este ZIP** y súbelo tal cual a **Vercel** (botón *Import Project* → *Upload*).
2. Vercel construye y te da una URL pública.
3. Para correr local (opcional): `npm i` y `npm run dev`.

> Más adelante podremos conectar Supabase y WhatsApp Cloud API.
